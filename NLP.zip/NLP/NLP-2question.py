from collections import Counter

# Toy corpus
corpus = [
"low","low","low","low","low",
"lowest","lowest",
"newer","newer","newer","newer","newer","newer",
"wider","wider","wider",
"new","new"
]

# add end marker
corpus = [" ".join(list(word)) + " _" for word in corpus]

def get_bigrams(corpus):
    pairs = Counter()
    for word in corpus:
        symbols = word.split()
        for i in range(len(symbols)-1):
            pairs[(symbols[i], symbols[i+1])] += 1
    return pairs

def merge_pair(pair, corpus):
    bigram = " ".join(pair)
    replacement = "".join(pair)
    new_corpus = []
    for word in corpus:
        new_word = word.replace(bigram, replacement)
        new_corpus.append(new_word)
    return new_corpus

# learn merges
num_merges = 10
for i in range(num_merges):
    pairs = get_bigrams(corpus)
    if not pairs:
        break
    best = pairs.most_common(1)[0][0]
    print("Step", i+1, "Top pair:", best)
    corpus = merge_pair(best, corpus)

    vocab = set(" ".join(corpus).split())
    print("Vocabulary size:", len(vocab))
