import spacy

nlp = spacy.load("en_core_web_sm")

text = """I can't believe it's already February! Machine learning models don't always work perfectly, but they're improving every day. People in New York often say "time flies". Isn't it amazing?"""

doc = nlp(text)

tokens = [token.text for token in doc]
print(tokens)
